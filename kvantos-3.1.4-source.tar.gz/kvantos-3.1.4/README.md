# KvantOS 3.1.4

Source and usage notes for the 3.1.4 release; see [release notes](RELEASE.md), [changelog](CHANGELOG.md) and [roadmap](ROADMAP.md).

> **New in 3.0** — the move to **64-bit**: alongside the classic 32-bit
> kernel there is now a second build, `kvant64.bin`, compiled for
> x86-64 long mode (PML4 paging, 64-bit interrupt frames and GDT/TSS).
> And with it comes a **UEFI loader** written in plain C —
> `boot/kvantefi.c`, assembled into `BOOTX64.EFI` with no GRUB, no
> legacy MBR and no CSM: the only road onto modern hardware. The ISO is
> hybrid — it boots on old BIOS machines through GRUB and on UEFI
> firmware through the EFI stub. The full story is in
> [CHANGELOG.md](CHANGELOG.md).

*Read this in [Русский](README.ru.md).*

A completely hand-written **x86 operating system** with two kernels:
the classic **32-bit** build (`kvant.bin`, booted by **GRUB 2** through
the Multiboot 1 specification) and, since 3.0, a **64-bit** build
(`kvant64.bin`, booted by its own **UEFI stub** on EFI x86-64 firmware).
Own monolithic kernel. No C standard library — only the compiler's
freestanding headers.

```
   ██╗  ██╗██╗   ██╗ █████╗ ███╗   ██╗████████╗
   ██║ ██╔╝██║   ██║██╔══██╗████╗  ██║╚══██╔══╝
   █████╔╝ ██║   ██║███████║██╔██╗ ██║   ██║
   ██╔═██╗ ╚██╗ ██╔╝██╔══██║██║╚██╗██║   ██║
   ██║  ██╗ ╚████╔╝ ██║  ██║██║ ╚████║   ██║
   ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝
```

## C Workshop — build applications inside the OS

Click **C Workshop** on the desktop or in the **KVANT** menu for `hello.c`.
The **Build** button creates a native `.kapp`; **Run** rebuilds and starts it. Both **32-bit BIOS**
and **64-bit UEFI** kernels are supported without a host GCC or network inside
the guest. This is a limited C subset, not full GCC. **Save** writes source;
**Open** shows a RAM/disk file picker. KvFS persists files; RAM-only files disappear on reboot.
The Workshop and Notepad have independent documents.

[Workshop guide](sdk/WORKSHOP.md) · [Release 3.1.4](RELEASE.md)

## FAT32 / USB import and write policy (3.1.4)

Version 3.1.3 adds **Import** to Notepad and C Workshop: mouse selection
of a FAT volume/folder/file, separate local name, a safe RAM copy and later
KvFS persistence. The source is not modified. USB mass-storage covers UHCI, EHCI with OHCI
companions and a native full-speed OHCI backend. xHCI/USB 3 and UAS are not
supported; hub/TT routing is limited and experimental. Physical media and
VirtualBox are not qualified by the software test suite.
The **128-line editor limit is removed**: above it, an amber warning appears
without blocking import/edit/save/build. There is no independent row limit;
the editor byte pool is <64 KiB with 120 bytes/line. The compiler's separate
16000-byte source limit remains. See [Workshop](sdk/WORKSHOP.md).

**GPT + FAT32** now works too, including an MSR before the data partition,
CRC validation and backup metadata; read-only, no repartitioning/reformatting.
[Instructions and limits](USB-IMPORT.md).

All ordinary FAT volumes mount read-only. Writes are only possible on a
pre-provisioned FAT32 volume with the owned-file `KVANTWAL.SYS` journal, after
recovery checks and an explicit per-session `fatwrite VOLUME enable`. The kernel
does not create/reset the journal; unprepared and damaged volumes stay read-only
or are withheld. See [storage safety policy](docs/STORAGE-M2.md).

## Quick start

```bash
make          # build everything: kvant.bin (32-bit), kvant64.bin
              # (64-bit) and kvantefi.efi (the UEFI loader)
make iso      # build the bootable image, build/kvantos.iso
make run      # run in QEMU (the kernel log is mirrored to COM1/stdout)
```

The image boots on real hardware too: write `kvantos.iso` to a USB stick
(`dd if=build/kvantos.iso of=/dev/sdX bs=4M`) or attach it as a CD in
VirtualBox/VMware.

### Tests

```bash
make -C tests/fs image && make -C tests/fs check  # FAT/NTFS drivers; system tools and sudo required
make release                                       # prepare the ISO for the boot smoke test
tests/boot/qemu-smoke.sh release/kvantos.iso       # BIOS + UEFI, wait for the shell prompt
```

The boot test requires QEMU and OVMF; see [tests/boot/README.md](tests/boot/README.md).

### UEFI boot (new in 3.0)

The ISO carries a second El Torito entry: a FAT16 ESP image
(`tools/mkesp.py`, pure Python — no `mtools` needed) with
`/EFI/BOOT/BOOTX64.EFI` and `/boot/kvant64.bin`. On firmware that boots
UEFI-only (no CSM) the stub reads the kernel from the boot volume,
loads the `.kapp` applications from `/boot/apps`, picks a 1024x768 (or
the best fitting) GOP graphics mode, converts the EFI memory map into a
Multiboot-1 style `multiboot_info`, exits the boot services and jumps
into the 64-bit kernel — which from that point on behaves exactly like
the 32-bit build: same shell, same applications, same drivers.

Applications are built for both kernels: `release/apps` carries the
32-bit `.kapp` files (for `kvant.bin` and the GRUB/floppy paths) and
`release/apps64` the 64-bit ones (for `kvant64.bin`); a header flag
(`KAPP_FLAG_ARCH64`) makes each kernel refuse files of the wrong
bitness instead of crashing on them.

**Current 64-bit limit:** the physical-frame allocator and framebuffer mapping
still use 32-bit physical addresses. The kernel can use at most the first 4 GiB
of physical address space; a GOP framebuffer above 4 GiB is rejected and the
system falls back to text mode.

### Building without GRUB

`make iso` needs the GRUB toolchain (`grub-mkstandalone`, `grub-file`) and
`xorriso`. Where those are unavailable there is a fallback path that needs
only `nasm` and `python3`:

```bash
make iso-direct   # build/kvantos-direct.iso via tools/mkdirect.py
```

Instead of GRUB the ISO carries a tiny self-contained Multiboot loader
(`boot/direct.asm`, about a kilobyte). It enables A20, reads the E820
memory map, switches the adapter to VBE 1024x768x32 exactly as the
kernel's Multiboot header asks, loads the kernel segments to 1 MiB and
the `.kapp` modules to 2 MiB, builds a full `multiboot_info` (command
line, modules, memory map, framebuffer) and jumps to the kernel. The ISO
itself is written by the vendored pure-Python `pycdlib`
(`tools/vendor`). Note the GRUB build additionally provides the boot
menu (text/safe mode, language) and the `hdboot.img` installer payload;
`iso-direct` boots straight into graphics mode with all embedded
applications.

## Interface language

The whole system speaks **English by default** and can switch to **Russian at
run time** — the entire interface, shell, GUI and bundled applications.

| How | What to do |
|---|---|
| GRUB menu | pick the second entry, *KvantOS - Russian interface* |
| Kernel command line | add `lang=ru` |
| Inside the system | type `lang ru` (and `lang en` to switch back) |

The mechanism is a single macro, `T(en, ru)`, declared in `include/i18n.h`: it
picks a string from a pair at run time, so both languages live in one binary and
switching costs nothing. Applications reach the same switch through the ABI —
`sys->lang()` or the `KV_T(sys, en, ru)` macro. Every source comment, build
script and document in the repository is in English; the Russian documents are
kept beside them as `*.ru.md`.

## What is implemented

### Booting
* Multiboot 1 header, assembly entry point (`boot/boot.asm`)
* Parsing of the multiboot structure: memory map (`mmap`), bootloader name, RAM size
* A GRUB menu with nine entries, including safe mode, text mode and Russian interface

### Kernel
| Subsystem | Details |
|---|---|
| **GDT** | 5 descriptors: ring 0 and ring 3 code/data, plus a TSS for a future userspace |
| **IDT** | 32 exception handlers, 16 IRQs, vector `0x80` reserved for system calls |
| **PIC 8259** | IRQs remapped to vectors 32–47, proper EOI handling |
| **PIT** | 500 Hz system timer (2 ms scheduling quantum), the source of task preemption |
| **PMM** | A bitmap of 4 KiB physical pages built from the multiboot mmap |
| **Paging** | Identity mapping of the first 16 MiB, `CR3`/`CR0.PG`, a `#PF` handler dumping `CR2` |
| **Heap** | 10 MiB, `kmalloc`/`kfree`/`kcalloc`, first fit, splitting and merging of neighbouring blocks, magic numbers against corruption |
| **Scheduler** | Round robin with preemption on IRQ0, context switching in assembly, ready/sleeping/finished states, automatic reaping of dead tasks |
| **ramfs** | A flat in-RAM filesystem: create, read and delete files |

### Graphics mode — the `guimenu` command

A full windowing environment, **KvantGUI**, on top of the linear VBE framebuffer
requested from GRUB through the video fields of the Multiboot header (1024×768×32).

* **Desktop** — a gradient background and 9 icons with hand-drawn pixel art
* **Windows** — a gradient title bar, a shadow, a close button, dragging with the
  mouse, z-order (a click raises the window)
* **Taskbar** — buttons for open windows, an RTC clock, a memory gauge
* **PS/2 mouse** — an IRQ12 driver, the cursor drawn in software, support for
  clicks, dragging and double clicks
* **Adaptive, damage-based double buffering** — dirty rectangles are merged,
  restored from a cached wallpaper/icon layer, and only intersecting windows are
  redrawn and presented. Cursor motion updates its old and new bounds; a live
  app does not rerasterize the rest of the desktop. The KvApp ABI 3 `delta_ms()`
  clock keeps simulation updates stable at 30/60 fps or uncapped (`L` selects
  the render cap); ABI-2 applications remain supported.
* **Mini-applications**: About, Monitor (memory, heap and tasks in real time),
  Files (ramfs), Terminal (help/mem/ps/ls/date/uptime/about/clear), Paint
  (a 44×26 canvas with a palette), Settings, Help, Programs

#### The Settings application

A graphical counterpart of the `vidmode`/`refresh` commands, with three tabs:

* **Display** — a grid of available resolutions (modes that do not fit into video
  memory are hidden), a refresh rate selector and an Apply button. The resolution
  changes **while the environment keeps running**: the buffer for the new stride
  is allocated *before* the adapter is touched, windows are pulled back inside the
  screen and the cursor is re-centred. If the buffer cannot be allocated the mode
  is left untouched — the desktop is never left rendering straight into video
  memory, which on real hardware means uncached writes and an apparent freeze.
  After a successful change a banner asks for confirmation: **Enter** keeps the
  new mode, **Esc** undoes it, and after 15 seconds without input the previous
  resolution is restored automatically, so an unusable mode can never lock you
  out (`screenshots/56_revert_banner.png`, `57_auto_reverted.png`).
* **Appearance** — 6 accent colours (they repaint window titles, the Start button
  and the background), 4 wallpaper styles (gradient, night, grid, plain), plus
  checkboxes for window shadows and seconds in the clock.
* **System** — version, CPU, memory, heap, uptime, the number of tasks and PCI
  devices, and a way back to the console.

Internally there is a system of *hit areas*: widgets register their rectangles
when the scene is redrawn, and a mouse click looks for a hit in reverse drawing order.

Mouse navigation: single-click a desktop icon or use **KVANT → application**;
the taskbar switches windows, title bars drag them, and the cross closes them.
Use **KVANT → Exit to console** to leave. Single-letter G/B/E/T/Q/W and other
desktop launch/close shortcuts are gone. In-game keyboard controls are unchanged.

Both editors support click-to-position, drag selection with edge auto-scroll,
shared Copy/Cut/Paste, independent multi-step Undo/Redo, Select all, draggable
vertical/horizontal scrollbars and the mouse wheel. Open / Save as provide
RAM/disk file lists, an editable name field and clickable confirmation/cancel.
New/open/close/exit protect unsaved text; replacing another file and deletion
require confirmation. Notepad now saves to RAM + mounted KvFS too. Without a
disk RAM is temporary. Text input, arrows and optional Ctrl+C/V/X/A/Z/Y/S,
Ctrl+O/N/W and F5/F6 remain. Esc dismisses a dialog/selection, not the editor.

Optional **KVANT → MouseKeys** (or NumLock): keypad 8/2/4/6 and 7/9/1/3 move,
5 clicks, 0 holds, decimal releases; Shift is precise, Ctrl faster, +/- change
speed. Off by default.

![Mouse selection in Notepad](screenshots/63_notepad_mouse_uefi64.png)
![Mouse-first C Workshop](screenshots/64_workshop_mouse_uefi64.png)

### Video adapter, resolution and refresh rate

The kernel drives the video adapter itself, without asking the BIOS: `int 0x10`
is unreachable from protected mode, so the registers are programmed directly.

| Command | Purpose |
|---|---|
| `lspci` / `lspci -v` | enumerate PCI devices, classes, BARs, IRQs |
| `gpu` | video adapter model, video memory size, driver, current mode |
| `vidmode` | a table of 12 modes with a check whether they fit into video memory |
| `vidmode 6` | switch to mode #6 from the table |
| `vidmode 1280 720 32` | an arbitrary resolution and colour depth |
| `refresh` | the current rate: computed from CRTC and measured against VSync |
| `refresh 75` | set the frame rate |

**How it works.** The PCI bus is scanned through ports `0xCF8`/`0xCFC`
(256 buses × 32 slots, multifunction devices included); the amount of video
memory is determined by writing a mask into a BAR. Resolution changes go through
the **Bochs VBE Extensions** (ports `0x1CE`/`0x1CF`) — understood by QEMU, Bochs
and VirtualBox; for VMware there is a path through the SVGA II registers in BAR0.
After a switch the driver re-maps video memory into the address space,
recomputes the pixel format (BGRX for 32/24 bits, RGB565 for 16) and rebuilds the
console grid — 1280×1024, for instance, yields 160×64 characters. The `guimenu`
environment picks the new resolution up automatically.

**The frame rate** is changed by reprogramming the vertical CRTC timings:
Vertical Total, Retrace Start and Retrace End are recomputed together, in one
go. Changing only Vertical Total is not allowed — the sync pulse would stay
where it was, the signal would become invalid and the monitor would blank the
picture (this bug was caught on screenshots and fixed). In linear framebuffer
mode the scan-out is owned by the host, so the system says so honestly instead
of showing an invented number.

### Drivers
* **Console** — works in two modes: classic VGA 80×25 through 0xB8000 with its
  own font in plane 2, or software glyph rendering straight into the framebuffer
  (128×48 characters at 1024×768). The choice is automatic
* **VBE framebuffer** — 32/24/16 bits per pixel, fills, gradients, rounded
  rectangles, text, hardware scrolling of an area
* **PS/2 mouse** — IRQ12, 3-byte packets, sync-bit and overflow checks
* **Cyrillic** — a CP866 font generated from system PSF files
  (`tools/mkfont.py`); the driver decodes UTF-8 → CP866 on the fly
* **PS/2 keyboard** — scan code set 1, Shift/Ctrl/CapsLock, arrows, a ring
  buffer, handling inside the interrupt
* **RTC/CMOS** — reading date and time, BCD and 12/24-hour support
* **COM1** — every kernel message is mirrored to the serial port for debugging
* **PC speaker** — sound generated through PIT channel 2

### Filesystems and volumes
KvantOS reads the partition table of every ATA disk, recognises the filesystems
it finds and mounts them into one namespace under `/mnt`.

| Filesystem | Read | Write | Notes |
|---|---|---|---|
| **FAT32** | yes | enrolled volume + opt-in only | VFAT/subdirectories; M2.4 owned WAL, default RO |
| **FAT16** | yes | no in normal ISO | legacy write algorithm tested separately; production RO |
| **NTFS** | yes | **no** | MFT, resident and non-resident data, B-tree directories |
| KvFS | yes | yes | the system's own format, for installed applications |
| ramfs | yes | yes | files in RAM, from the boot modules |

**FAT32/FAT16** share a driver. Normal writes require an enrolled FAT32 volume
and explicit opt-in; ordinary volumes are RO. It reads and, where enabled,
creates long names in UTF-16,
walks subdirectories, allocates and frees clusters through both copies of the
FAT, keeps the FSInfo free-cluster hint up to date, and creates directories with
their `.` and `..` entries. Disposable-image writes are checked with independent `fsck.fat`; any pending
private WAL must be recovered by KvantOS before another OS writes/repairs it.
Physical Windows/USB compatibility has not been qualified.

**NTFS is deliberately read-only.** The driver understands the Master File
Table, the update-sequence fixups, resident and non-resident `$DATA` attributes,
runlists including sparse extents, `$ATTRIBUTE_LIST` for fragmented files, and
directory B-trees built from `$INDEX_ROOT` and `$INDEX_ALLOCATION`. It does not
write, and that is a design decision rather than an omission: NTFS journals
every change through `$LogFile`, and a driver that modified the volume without
maintaining the journal, the cluster bitmap and the B-tree balance would produce
a filesystem that Windows refuses to mount. Compressed and encrypted streams are
reported as an error instead of being returned as garbage.

Not supported: exFAT (a different format that merely shares the NTFS partition
type — it is recognised and skipped), and copying whole directory trees in one
action.

### The file manager
A two-pane manager in the spirit of Norton Commander, on the `Files` desktop
icon. The left pane is the source, the right one the destination, so a copy is
always "from the active pane to the other one" — including from NTFS to FAT32.

* `Tab` — switch pane, `Enter` — open a directory or preview a file
* `Backspace` — go up; at the root of a volume it moves to the next volume
* `F5` — copy, `F7` — new directory, `F8` — delete (with confirmation),
  `F2` — refresh, `F3` — preview
* the preview shows text as text and binary files as a hex dump
* read-only volumes are marked as such, and every write to one is refused with
  an explanation rather than a silent failure

### The kvsh shell
An interactive command line with history (↑↓ arrows), Ctrl+L and Ctrl+C.

```
help      about     clear     echo      mem       cpu
uptime    date      ps        spawn     kill      ls
cat       write     rm        touch     cp        mv
wc        grep      hexdump   sum       colors    color
beep      alloc     lang      history   crash     reboot
poweroff  guimenu   gfx       lspci     gpu       vidmode
refresh   setup     disk      format    df        dls
dcat      install   uninstall apps      hwreport  mount
rescan    vls       vcd       vcat      vcp       vrm
vmkdir    uname     sysinfo   hostname  whoami    cal
calc      hex       bin       dec       rand      seq
rev       matrix    fortune   melody    countdown ascii
leds      sleep
```

`mount` lists the mounted volumes with their type, label and free space,
`vls`/`vcat`/`vcp`/`vrm`/`vmkdir` work on any volume by path
(for example `vcp /mnt/hda2/readme.txt /mnt/hda1/`), and `rescan` looks for
volumes again after a disk has been swapped.

`guimenu` starts the graphical environment, `gfx` reports the video mode,
`lang` switches the interface language.

The utilities batch: `kill` terminates a task from `ps`; `uname`/`sysinfo`
summarise the system; `cal` prints a month calendar with today highlighted;
`calc` evaluates integer expressions with parentheses; `hex`/`bin`/`dec`
convert number bases; `rand` and `seq` produce numbers; `wc`/`grep`/`hexdump`/
`sum`/`touch`/`cp`/`mv` work with ramfs files; `matrix` shows digital rain;
`fortune` prints a quote; `melody` and `countdown` use the PC speaker;
`leds dance` puts the keyboard indicators through a light show; `color`
changes the shell text colour.

A live status line at the top is updated by a separate background task and shows
RAM usage, the number of tasks and the system uptime.

## Project layout

```
kvantos/
├── boot/
│   ├── boot.asm        entry point, Multiboot, GDT/IDT/paging/context switch
│   └── isr.asm         48 interrupt stubs + the common dispatcher
├── include/
│   ├── kernel.h        the single kernel header
│   ├── i18n.h          the T() macro and run-time language switching
│   └── kvapp.h         the application ABI, version 3 (with ABI-2 compatibility)
├── kernel/
│   ├── main.c          subsystem initialisation
│   ├── i18n.c          the current language and its selector
│   ├── gdt.c  idt.c    descriptor tables, PIC
│   ├── pmm.c  paging.c heap.c    memory management
│   ├── sched.c         the task scheduler
│   ├── vga.c  serial.c printf.c  output
│   ├── keyboard.c timer.c rtc.c cpu.c   drivers
│   ├── fb.c            the linear framebuffer (VBE) driver
│   ├── pci.c           PCI bus enumeration, BAR reading
│   ├── vbe.c           resolution (BGA/SVGA) and CRTC timing changes
│   ├── cmd_video.c     the lspci / gpu / vidmode / refresh commands
│   ├── gui.c           the graphical environment: windows, panel, applications
│   ├── kapp.c          the .kapp application loader
│   ├── kvfs.c ata.c    the disk filesystem and its ATA driver
│   ├── setup.c         installation onto a hard disk
│   ├── mouse.c         the PS/2 mouse driver
│   ├── charset.c       UTF-8 -> CP866
│   ├── ramfs.c shell.c panic.c string.c
│   └── font8x16.c      the generated VGA font with Cyrillic
├── sdk/                the application SDK: samples, linker script, packer
├── grub/grub.cfg       the bootloader menu
├── tools/mkfont.py     the font generator
├── linker.ld           the kernel at address 1 MiB
└── Makefile
```

## Technical decisions

**Why a custom font.** The stock VGA character generator only carries CP437 —
there is no Cyrillic in it. At start-up the kernel reprograms the VGA Sequencer
and Graphics Controller, writes 256 glyphs of 8×16 into plane 2 and returns the
adapter to text mode. The sources stay in UTF-8; the driver converts them to
CP866 with a streaming decoder.

**Mapping the framebuffer.** Video memory sits around `0xFD000000`, far beyond
the identity mapping of the first 16 MiB. That is why `fb_init` only parses the
Multiboot fields, while the buffer pages are mapped one-to-one right after
paging is enabled — otherwise the very first access would raise a `#PF`.

**No libgcc.** Linking goes straight through `ld` without standard libraries, so
64-bit divisions (`__udivdi3`) are replaced by arithmetic built from 32-bit
operations — the kernel drags in no external dependencies.

**Context switching.** `context_switch` saves `EFLAGS`, `ebp`, `ebx`, `esi` and
`edi` on the stack of the old task and restores them from the stack of the new
one. The stack of a newly created task is filled with exactly the same frame, so
the first `ret` takes execution straight to its entry point, and underneath it
lies the address of `task_exit` — a task finishes correctly simply by returning
from its function.

## Licence

MIT.

## Screenshots

| File | What it shows |
|---|---|
| `screenshots/47_en_shell.png` | The kvsh shell in English: `gpu`, `df`, `lang` |
| `screenshots/48_en_help.png` | The full command list |
| `screenshots/49_en_settings.png` | The Settings application, the Display tab |
| `screenshots/50_en_programs.png` | The Programs window |
| `screenshots/51_grub_menu_lang.png` | The GRUB menu with the Russian entry |
| `screenshots/52_ru_help.png` | The same help after booting with `lang=ru` |
| `screenshots/53_ru_gui.png` | The graphical environment in Russian |
| `screenshots/54_lang_switch_runtime.png` | Switching with the `lang ru` command at run time |

Frames 01–46 cover the earlier stages: the console, the GUI, video modes,
applications and installation onto a hard disk.


### The file manager and filesystems

| | |
|---|---|
| ![Two panes: FAT32 and NTFS](screenshots/47-file-manager.png) | ![Previewing a file](screenshots/48-file-preview.png) |
| Two panes over real volumes: FAT32 on the left, NTFS on the right | The preview shows text as text, binary as a hex dump |
| ![Copying from NTFS to FAT32](screenshots/49-copy-ntfs-to-fat32.png) | ![Confirming a deletion](screenshots/50-delete-confirm.png) |
| Copying a file off a read-only NTFS volume onto FAT32 | Deleting always asks first |

![Volumes in the shell](screenshots/51-shell-volumes.png)

`mount` lists what was found, `vls` reads an NTFS directory, `vcp` copies
across filesystems.

## Working test screenshots

The `testshots/` folder holds 64 frames captured from QEMU while debugging:
frame-rate measurements and both runs of the notes editor, including shots of
the bugs themselves. The index is `testshots/README.md`, and the whole gallery in
one file is `testshots/index.html`. Unlike `screenshots/`, these are diagnostic
drafts rather than a showcase.

## Applications

KvantOS can **install programs onto a disk** — they survive a reboot, as in a
real system.

An application is a `.kapp` file: a flat image with a 64-byte header that the
kernel loads at a fixed address and whose `kapp_main()` function it calls. The
program receives a versioned system-function table for drawing, keyboard, mouse,
files, time and sound. ABI 3 appends `delta_ms()` for elapsed-millisecond,
frame-rate-independent simulation: the non-canvas service count rises from 30 to
31, and the full table has 33 function pointers (32 in ABI 2) when `width()` and
`height()` are included. The new pointer is null for ABI-2 applications, so
existing binaries continue to run unchanged.

The quickest start is to embed a program into the boot image:

```bash
cd sdk && make                       # build the samples
cd .. && ./sdk/addapp.sh sdk/build/snake.kapp
```

The resulting `release/kvantos.iso` can be attached to VMware/VirtualBox or
burned to a disc: the applications will be in the system straight away, **with no
hard disk at all**. A disk is only needed so that programs can save their files.

Inside the system: the **Programs** icon or **KVANT → Programs** lists, launches and removes
them. From the shell: `disk`, `format`, `install`, `apps`, `dls`.

Eleven applications are bundled — three richly commented samples plus eight
more: **Clock** (an analogue dial, integer trigonometry), **Notes** (an editor
keeping its text on disk), **Snake** (a small game), **Calculator** (buttons
and keyboard input), **Paint** (mouse drawing with a palette), **Pong** (you
against the machine), **Life** (Conway's Game of Life), **Stars**
(a starfield screensaver), **Mines** (Minesweeper with a keyboard cursor and
flags), **2048** (the sliding-tiles puzzle) and **Maze 3D** (a fixed-point
first-person ray-cast maze).

If an application raises a CPU exception, the system attempts to remove it
and continue — this is verified by a dedicated test. However, `.kapp` programs
run in ring 0, not in a sandbox: run only trusted applications. Exception
recovery cannot protect the kernel from arbitrary memory writes or device I/O.

**The full developer guide is [APPS.md](APPS.md)**: the file format, a reference
for every ABI function, the life cycle, building, installing, debugging, an error
reference and a list of things you must not do.

## Installing onto a hard disk

KvantOS can install itself onto a hard disk and boot from it unaided — with no
USB stick and no disc in the drive.

Boot from the ISO or the floppy and run in the shell:

```
setup            # show disk information and a warning
setup --yes      # install (the filesystem is created anew)
setup --yes --keep   # install, keeping the files already there
```

The same thing in graphics mode: the **Programs** icon → the **Install** button.
The button is only visible while the system runs from removable media; after
installation it disappears.

Then run `poweroff`, remove the medium and switch the machine on — it will boot
from the hard disk.

### What happens during installation

| Disk area | Contents |
|---|---|
| sector 0 | MBR: GRUB code (446 bytes) + the partition table |
| sectors 1–2047 | the body of the GRUB bootloader (`hdboot.img`, ~386 KiB) |
| sector 2048 | the KvFS superblock |
| sectors 2049–2056 | the file directory |
| sector 2057 onwards | file data |

A single partition is created: active, type `0x83`, from sector 2048 to the end
of the disk. The kernel and the applications live inside the bootloader image
itself, so no separate service partition is needed. After writing the
bootloader the installer moves every ramfs file into KvFS — the programs stay
where they were.

**Warning:** installation overwrites the boot record of the disk and everything
previously on it becomes unreachable. In a virtual machine the disk must be
**IDE**, not SCSI.

A detailed step-by-step guide, including real hardware, is in
[INSTALL.md](INSTALL.md).

## Code audit

A detailed history of the defects found and fixed — including video memory
caching, heap overflows, CapsLock and the 640×480 icon layout — is in
[AUDIT.md](AUDIT.md).

## Media and building

| File | Size | When to use it |
|------|------|----------------|
| `release/kvantos.iso` | ~1.4 MB | Main hybrid CD/DVD or USB image; GRUB menu and installer payload |
| `release/kvantos-direct.iso` | ~4.7 MiB | GRUB-free BIOS + UEFI image; boots straight into graphics |
| `release/kvantos-floppy.img` | 1.44 MB | When the drive is worn out and GRUB hangs at "Welcome to GRUB!" |

The GRUB ISO and floppy are **monolithic**: the GRUB modules, `grub.cfg` and
kernel are embedded, so nothing is read from the medium afterwards. The direct
ISO is self-contained too: it embeds the loader, kernel and applications and
also includes the UEFI system partition.

```
make iso      # the bootable ISO
make floppy   # a 1.44 MB floppy image
make run      # run in QEMU
```

### Verified on real hardware

Samsung RV410 (NP-RV410L): Pentium T4500, GL40 + ICH9M chipset, GMA 4500M, 2 GB
of RAM — booted from the floppy image, the kvsh console works.

### Diagnosis without a screen

- **NumLock lit up** — the kernel reached keyboard initialisation.
- **Three indicators blinked plus a beep** — the system is fully up.
- The `hwreport` command prints a summary of CPU, RAM, PCI and video mode.

### C Workshop 3.1.1 (actual QEMU captures)

![x86-64 Workshop: successful diskless build](screenshots/60-c-workshop-x64.png)
![Native application compiled inside the x86-64 Workshop](screenshots/62-native-c-x64.png)


### 3.1.4: RU input, find/replace and storage state

The **EN/RU** chip or **Alt+Shift** selects Russian ЙЦУКЕН in both editors and
search fields (Caps/Shift, ё/Ё/№ included). UI language is independent. Filename
fields, shell commands and the application key ABI keep physical English input;
Ctrl shortcuts remain usable. **Find** / Ctrl+F opens literal, case-sensitive,
wrapping search; Ctrl+H focuses replacement. Previous/Next, Replace/Replace all
are clickable. Replace first selects a match if the selection does not match.
Each field permits 127 UTF-8 bytes: Tab changes field, Ctrl+U clears,
Enter/Shift+Enter searches forward/backward, Esc closes. Replace all is one Undo;
a line/text-budget failure preserves the document and history. No regex/case folding.

The permanent footer distinguishes Modified, RAM and KvFS for this document
revision, including no disk/write failures. After import, **Keep: KvFS** saves
only when clicked, never back to the source USB drive. No disk means temporary
RAM only. A failed disk write does not mark the document saved; a partial RAM
success is reported separately. This is not power-loss protection or monitoring
of every external overwrite.

### M2.1 — write groundwork, not complete FAT32 saving

KvFS replacement ordering and ATA flush error handling are hardened. USB
WRITE(10)/SYNCHRONIZE CACHE are tested only in a separate lab build against
marked disposable scratch images. **Normal USB/FAT mounts remain RO; FAT32
file-write recovery and editor volume/folder selection are still pending.**
See [M2 status and tests](docs/STORAGE-M2.md).

### M2.2a — FAT COW and host recovery prototype

FAT replacement retains the old chain until the new body is ready. Bounded
metadata undo accounts for FAT copies, FSInfo and fragmented directory/LFN slots.
1048 interrupted host-image operations pass independent fsck and namespace checks.
**Normal kernels have RAM undo, not persistent FAT power-loss protection; USB is
still RO and editor destination selection is pending.** See [limits and tests](docs/STORAGE-M2.md).

### M2.2b — actual USB/FAT guest writes and recovery lab

Explicit disposable-image enrollment now exercises common-VFS file writes and
persistent recovery **before mount publication**, with two disjoint FAT/WAL grants
and USB-generation fencing. Ordinary USB remains RO; lab ISOs are non-installable.
Real-media journal provisioning is still pending; editor selection is added below.
See [protocol and reproduction](docs/STORAGE-M2.md).

### M2.3a — explicit editor Save As destinations

Both editors offer **Save as -> Destination...**: cycle mounted volumes, navigate
folders, name the file and confirm replacement. Subsequent Save stays bound to
that VFS path; failures never silently save to another volume. RAM is labelled
temporary, RO/errors are explicit, and rescan requires choosing the destination
again. The quick default local save still keeps RAM+KvFS.

Normal images write RAM/KvFS only; ordinary USB remains RO. Actual GUI FAT saves
and unplug/recovery tests use explicitly owned disposable lab images, not real
flash drives. Production journal ownership and hardware tests still block full M2.
See [boundaries and reproduction](docs/STORAGE-M2.md).


### M2.4 — normal-kernel owned FAT journal file

The remaining software path is implemented: a preallocated `KVANTWAL.SYS` file,
exclusive ownership checks using both FATs and a validated undo overlay, recovery
**before namespace publication**, and bounded generation-fenced USB leases.
All FAT mounts now default RO (including ATA/FAT16). Only enrolled FAT32 can opt
in per session with `fatwrite VOLUME enable|disable`. Both editors then use the
normal VFS Save As path; no lab kernel or implicit RAM fallback is required.

The Linux `tools/fat-wal.py` provisioner defaults to read-only inspection and needs
explicit serial confirmation to create a new journal. It never formats/repartitions
or resets an existing log. Standard file allocation is staged on private images;
unsupported/full/fragmented/conflicting layouts leave the original unchanged.
Physical access is separately gated to unmounted partition block devices, not
whole disks. Those device-policy guards have software tests, not hardware proof.

**Exclusive-media contract:** after an uncertain save/crash/unplug, recover in
KvantOS BEFORE another OS writes or repairs the FAT volume. Other FAT drivers do
not understand this WAL; FAT's dirty bit is not a cross-OS lock. Initial host
provisioning itself must not be interrupted and requires an independent backup.
The normal-image/software fault/GUI/fsck suites do not close physical USB or
VirtualBox passthrough acceptance. No automatic push/tag/release was performed.
See [protocol, safety limits and reproduction](docs/STORAGE-M2.md).

## AHCI SATA — DMA, default RO and explicit WAL writes

M3.1 added SATA DMA reads, FAT volumes under `/mnt/sataNpM`, mouse import and
copying to RAM/KvFS. M3.2 adds WRITE DMA EXT / FLUSH EXT and shared owned-WAL
recovery before publication. SATA still defaults RO: only explicitly enrolled
FAT32 may opt in per session with `fatwrite VOLUME enable`. Transport-enforced
bounded generation leases protect writes and flush. No AHCI installer or hotplug;
physical SATA/VBox and M2 physical USB acceptance remain open.
See [current M3.2](docs/STORAGE-M3.2.md) and [historical M3.1](docs/STORAGE-M3.md).

### M3.3 — OHCI full-speed USB storage

A distinct OHCI HCCA/ED/TD backend reuses BOT/SCSI and FAT owned WAL, with private
per-controller DMA memory, bounded waits and reboot-only fencing after I/O faults.
Default RO and explicit prepared-FAT32 opt-in remain unchanged. Standalone OHCI
12 Mb/s is separate from UHCI and EHCI high-speed/companions. No hubs, USB HID,
xHCI or physical/VirtualBox qualification. See [M3.3](docs/STORAGE-M3.3.md).

### M3.5a — EHCI DMA safety prerequisite

EHCI now has a pinned private periodic/QH/qTD/bounce pool per initialization
attempt (including failed starts), per-controller serialization and bounded
waits. IN copyout and toggle changes require a retired async schedule plus
consistent QH/qTD completion. Faults fence the HC until reboot; siblings on
that same HC may also become unavailable. Two independent QEMU HS controllers
are tested with debugger-timed detach; this is not IOMMU isolation or physical
qualification. Default RO, explicit prepared-FAT32 opt-in and WAL are unchanged.
At the M3.5a boundary, HS hubs/TT/splits were intentionally rejected. [Details](docs/STORAGE-M3.5A.md).

### M3.5b — experimental EHCI HS-only hub trees

At the M3.5b boundary, the development source accepts **HS hubs with HS descendants**,
checks hub protocols/descriptors and post-reset/live speed, and isolates every
root link before reusing descendant addresses. FS/LS behind EHCI remain disabled
before EP0: **no TT/split**, no multi-TT alternate activation. Default RO,
prepared-FAT32 opt-in and owned WAL are unchanged. Software evidence separates
actual-code host models, a separately patched QEMU HS-only hub fixture, and
stock-QEMU regressions; physical HS hubs/VBox remain unqualified. The optional
fixture does not replace stock QEMU and is not a complete USB2 TT model.
[Limits and reproduction](docs/STORAGE-M3.5B.md).

### M3.5c — experimental FS async TT behind HS hubs

The current preview admits **FS BOT leaves directly under HS hubs**, including
nested HS ancestors. Device speed, nearest TT hub/physical port and every
ancestor edge are checked separately. EHCI receives FS async QHs; hardware owns
the actual SS/CS sequence. IN copyout requires ASS retirement and an unambiguous
QH/qTD result, including SplitXState. Uncertain TT/errors fence the **whole HC
until reboot**; there is no CLEAR_TT_BUFFER recovery yet. Other HCs stay isolated.
FS hubs, LS/HID/periodic splits and multi-TT alternate 1 are not supported.

Evidence separates actual-backend host tests from an explicit, separately built
**TD-level SS/CS QEMU LAB**. Neither is wire/bandwidth/timing or physical/VBox
qualification. Default RO/prepared-FAT32 opt-in/WAL remain unchanged; no physical
media were opened. One initial parallel x64 large-save refusal remains
**unexplained**: the isolated full suite and archived-state cold recovery pass,
but stress reliability is OPEN. [Scope, limits and reproduction](docs/STORAGE-M3.5C.md).
